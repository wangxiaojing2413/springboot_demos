insert into Reader (username, password, fullname) values ('craig', 'password', 'Craig Walls');
insert into Reader (username, password, fullname) values ('walt', 'marceline', 'Walt Disney');
