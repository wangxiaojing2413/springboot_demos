package com.eumji.exception.exception;

/**
 * @author eumji
 * @package com.eumji.exception.exception
 * @name CustomException
 * @date 2017/3/27
 * @time 13:32
 */
public class CustomException extends Exception {
    public CustomException(String message){
        super(message);
    }
}
