## log4j2
log4j2是springboot 1.4.2后支持的log系统

log4j2.xml是log的配置文件
在application.yml中指向配置文件
